import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {RouterModule,Routes} from '@angular/router'
import { ListemployeeComponent } from '../listemployee/listemployee.component';
import { AddemployeeComponent } from '../addemployee/addemployee.component';

const routes: Routes =[
  {
    path:'',
    component:ListemployeeComponent
      },
  {
path:'Add-Employee',
component:AddemployeeComponent
  },
 
  {
    path:'Display-Employee',
component:ListemployeeComponent
  }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
  
})

export class MinemoduleModule { }
