import { MinemoduleModule } from './minemodule.module';

describe('MinemoduleModule', () => {
  let minemoduleModule: MinemoduleModule;

  beforeEach(() => {
    minemoduleModule = new MinemoduleModule();
  });

  it('should create an instance', () => {
    expect(minemoduleModule).toBeTruthy();
  });
});
