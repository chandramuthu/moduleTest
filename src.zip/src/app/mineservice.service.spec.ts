import { TestBed } from '@angular/core/testing';

import { MineserviceService } from './mineservice.service';

describe('MineserviceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: MineserviceService = TestBed.get(MineserviceService);
    expect(service).toBeTruthy();
  });
});
