


import { Component, OnInit } from '@angular/core';

import { Router } from '../../../node_modules/@angular/router';
import { MineserviceService, Employee } from '../mineservice.service';

@Component({
  selector: 'app-addemployee',
  templateUrl: './addemployee.component.html',
  styleUrls: ['./addemployee.component.css']
})
export class AddemployeeComponent implements OnInit {
createdEmployee:Employee;
createdFlag:boolean=false;
service:MineserviceService;

  constructor(service:MineserviceService,private router:Router) { 
this.service=service;

  }

  ngOnInit() {
    
  }
  pushemployee(data:any)
  {
    this.createdEmployee=new Employee(data.eid,data.ename,data.email,data.phone)
    this.service.pushemployee(this.createdEmployee);
  this.router.navigateByUrl("Display-Employee");

  }

}

