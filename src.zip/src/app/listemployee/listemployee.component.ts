

import { Component, OnInit } from '@angular/core';
import { MineserviceService, Employee } from '../mineservice.service';

@Component({
  selector: 'app-listemployee',
  templateUrl: './listemployee.component.html',
  styleUrls: ['./listemployee.component.css']
})
export class ListemployeeComponent implements OnInit {
  service:MineserviceService
  constructor( service:MineserviceService) {
    this.service=service
   }
   empdata:Employee[]=[]
  ngOnInit() {
    
this.service.fetchEmployees();
this.empdata=this.service.getEmployees();

  }
delete(eid:number)
{
  this.service.delete(eid);
}

column:string="id";
order:boolean=true;
sort(column:string)
{
if(this.column==column)
{
  this.order=!this.order;
}
else{
  this.order=true;
  this.column=column;
}
}

}


