import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { AddemployeeComponent } from './addemployee/addemployee.component';
import { ListemployeeComponent } from './listemployee/listemployee.component';
import{FormsModule} from '@angular/forms';
import { MineserviceService } from './mineservice.service';
import { MinemoduleModule } from './minemodule/minemodule.module';
import { HttpClient,HttpClientModule } from '../../node_modules/@angular/common/http';

@NgModule({
  declarations: [
    AppComponent,
    AddemployeeComponent,
    ListemployeeComponent,

  ],
  imports: [
    BrowserModule,
    MinemoduleModule,
    HttpClientModule,
    FormsModule,
  ],
  providers: [HttpClient,MineserviceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
